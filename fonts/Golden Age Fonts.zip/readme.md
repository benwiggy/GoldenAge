
The ZIP file contains the OTF font and the JSON file: that's probably the easiest way to download directly from Github.
